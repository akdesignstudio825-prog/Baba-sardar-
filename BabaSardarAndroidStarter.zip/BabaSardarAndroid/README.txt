BABA SARDAR SHOPPING — ANDROID STARTER PROJECT

What this is:
- An Android Studio project that opens the current Baba Sardar HTML storefront inside an Android WebView.
- This is starter source code, not a compiled APK and not a production-ready commerce backend.

Build an APK:
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio, choose Open and select the BabaSardarAndroid folder.
4. Let Gradle sync and install any SDK components Android Studio requests.
5. For a test install, choose Build > Build App Bundle(s) / APK(s) > Build APK(s).
6. Find the APK via the notification's locate link, commonly app/build/outputs/apk/debug/app-debug.apk.

Before launching for real:
- Connect a secure backend/database and admin dashboard.
- Add real inventory, user accounts, order persistence, delivery workflow and payment gateway.
- Configure privacy policy, support contacts, app icon, signing key and Play Console listing.
- Test purchases and security before accepting real orders.

Package ID: com.babasardar.shop
App label: Baba Sardar Shopping
